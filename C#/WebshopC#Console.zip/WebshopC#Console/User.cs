﻿using System;

public class User
{



    public string Username { get; }
    public string Password { get; }
    public string Email { get; }
    public string firstname { get; }
    public string lastname { get; }


    public Shoppingcart shoppingCart { get; }
    public List<Review> reviews { get; }













}
