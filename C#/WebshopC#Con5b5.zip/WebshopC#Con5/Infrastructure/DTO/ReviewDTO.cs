﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DTO
{
    public class ReviewDTO
    {

        public string Comment { get; set; }
        public int Rating { get; set; }






    }
}
