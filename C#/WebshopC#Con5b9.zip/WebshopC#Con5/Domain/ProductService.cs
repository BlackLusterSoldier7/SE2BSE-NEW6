﻿using Infrastructure;
using Infrastructure.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    // Handles product-related business logic 

    public class ProductService
    {


        private ProductRepository productRepository; 

        public ProductService()
        {
            this.productRepository = new ProductRepository();


        }


        
        public List<ProductDTO> GetAllProducts()
        {
            return productRepository.GetAllProducts();
        }






    }
}
