﻿namespace XUnitTestWebshop
{
    internal class ProductDTO
    {
        public int Price { get; internal set; }
    }
}