﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentation
{

    // Handles displaying menus to the user 
    public class MenuDisplayHandler
    {



        public void ShowMainMenu()
        {
            Console.WriteLine("Welcome to the Webshop Menu: ");
        }









    }
}
