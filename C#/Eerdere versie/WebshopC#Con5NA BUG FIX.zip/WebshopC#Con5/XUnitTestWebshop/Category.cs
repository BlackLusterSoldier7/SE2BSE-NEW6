﻿namespace XUnitTestWebshop
{
    internal class Category
    {
        private string v1;
        private string v2;

        public Category(string v1, string v2)
        {
            this.v1 = v1;
            this.v2 = v2;
        }
    }
}