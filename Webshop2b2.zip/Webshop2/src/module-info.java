module Webshop2 {
    requires org.junit.jupiter.api;
    requires org.junit.jupiter.params; // If you're using parameterized tests

    // If you have any exports or other module directives, place them here
}
